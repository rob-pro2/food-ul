# FOOD ORDER - UI
It is the interface work of the food ordering application. It consists of twelve pages in total. These pages:
- Main Page
- Login Page
- Register Page
- Home Page
- Detail Page
- Favorite Page
- Search Page
- Cart Page
- Checkout Page
- Successfuly Page
- Profile Page

