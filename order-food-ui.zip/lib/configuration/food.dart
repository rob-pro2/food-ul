class Food {
  int foodId;
  String foodName;
  String foodImageName;
  String foodCategory;
  String foodPrice;

  Food({
    required this.foodId,
    required this.foodName,
    required this.foodImageName,
    required this.foodCategory,
    required this.foodPrice});
}